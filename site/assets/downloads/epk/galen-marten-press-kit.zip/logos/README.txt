Galen Marten Music — original guitar-pick logos
All PNGs: 1464 x 1500 pixels, transparent backgrounds.
Black/red lettering: use on light backgrounds. White lettering: use on dark backgrounds.
Keep original proportions. For promotion of Galen Marten Music.
